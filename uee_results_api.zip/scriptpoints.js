/**
 * Created by DCH on 18/10/2016.
 */


const {validationResult, body} = require('express-validator/check');
let sqlEngine = require("mssql"),
    path = require("path"),
    memcached = require("./memcachPromise"),
    db = require("./msdb");


let _loginSchema = [
    body('user').exists(),
    body('password').exists(),
];


async function getScriptRawPoints(entrantID, ueedb_2) {
    let ueedb_2_request = new sqlEngine.Request(ueedb_2);
    ueedb_2_request.input("EntrantID", sqlEngine.Int, entrantID);
    let response = await ueedb_2_request.query(
        "SELECT BarcodeID, IsGat, Name, OriginBarcodeID, RawPoints, RawPointsMargin, ScaledPoints, SubjectGroupId, SubjectID, Variant, WorkRawPoints, 2-IsGat ScriptPages " +
        "FROM tScripts_Published_1 " +
        "WHERE (EntrantID = @EntrantID)\n" +
        "order by Orderby");
    return response.recordset;
}

async function getScriptTemplates(subjectID, ueedb_2) {
    let ueedb_2_request = new sqlEngine.Request(ueedb_2);
    ueedb_2_request.input("SubjectID", sqlEngine.Int, subjectID)
    let response = await ueedb_2_request.query(
        "SELECT [ID] TemplateID\
             ,[PageNum]\
             ,[TaskNum]\
             ,[ItemNum] DisplayName\
             ,[ItemOrder]\
         FROM [tScriptTaskTemplates]\
         WHERE variant = 1 and SubjectID=@SubjectID \
         ORDER BY ItemOrder, TemplateID"
    );
    return response.recordset;
}

async function getItemPoints(barcodeID, multiplier, ueedb_1) {
    let ueedb_1_request = new sqlEngine.Request(ueedb_1);
    ueedb_1_request.input("BarcodeID", sqlEngine.Int, barcodeID);
    ueedb_1_request.input("Multiplier", sqlEngine.Decimal(18, 2), multiplier);
    let response = await ueedb_1_request.query("SELECT t1.ID\
        ,t1.[PageNum]\
        ,t1.[ItemNum]\
        ,t1.[Points]*@Multiplier Points\
        ,isnull(t2.Points*@Multiplier,-1) AppealPoints\
    FROM [tScriptPoints] t1\
    left join [dbo].[tScriptAppealPoints_publish] t2 on t1.BarcodeID = t2.BarcodeID and t1.ItemNum=t2.ItemNum and t1.PageNum =t2.PageNum\
    WHERE t1.[BarcodeID] = @BarcodeID"
    );
    return response.recordset;
}

async function getImage(barcodeID, page, ueedb_1) {
    let ueedb_1_request = new sqlEngine.Request(ueedb_1);
    ueedb_1_request.input("barcodeID", sqlEngine.Int, barcodeID);
    ueedb_1_request.input("page", sqlEngine.Int, page);
    let response = await ueedb_1_request.query("SELECT t1.[ID]\
        ,[PageNum]\
        ,[BarcodeID]\
        ,[ImagePath]\
        ,t2.Image\
    FROM [dbo].[tScriptImages1] t1 join [dbo].[tScriptImages2] t2 on t1.ID = t2.ImageID\
    where t1.BarcodeID = @barcodeID and t1.PageNum = @page"
    );
    return response.recordset;
}


async function getAdmission(entrantID, ueedb_2) {
    let ueedb_2_request = new sqlEngine.Request(ueedb_2);
    ueedb_2_request.input("EntrantID", sqlEngine.Int, entrantID);
    let response = await ueedb_2_request.query(
        "SELECT     tUniversities.Code AS univCode, tUniversities.Name AS univName, left(tSpecialities.Code,7) AS specCode, tSpecialities.Code Code, tSpecialities.Name AS specName, \n" +
        "                      tAdmissions.Score, tAdmissions.Choice/10 Choice, isnull(isnull(tGrants.RatingNum, tGrantsProf.RatingNum),tGrantsProf2.RatingNum) AS RatingNum, isnull(isnull(tGrants.Amount, tGrantsProf.Amount),tGrantsProf2.Amount) AS GrantAmount\n" +
        "FROM         tAdmissions INNER JOIN\n" +
        "                     tSpecialities ON tAdmissions.SpecialityID = tSpecialities.ID left  JOIN\n" +
        "                      tFaculties on tSpecialities.FacultyID = tFaculties.ID  left join\n" +
        "                      tUniversities ON tFaculties.UniversityID = tUniversities.ID left JOIN\n" +
        "                      tGrants ON tAdmissions.EntrantID = tGrants.EntrantID and amount is not null left JOIN\n" +
        "                      tGrantsProf ON tAdmissions.EntrantID = tGrantsProf.EntrantID left JOIN\n" +
        "                      tGrantsProf2 ON tAdmissions.EntrantID = tGrantsProf2.EntrantID\n" +
        "WHERE     (tAdmissions.EntrantID = @EntrantID)");
    return response.recordset;
}

module.exports = {
    get loginSchema() {
        return _loginSchema
    },
    async login(req, res, next) {
        let pool;
        let EntrantId = 0;
        let props;

        let err = "";
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                console.error(errors.array());
                err = 'შეცდომაა მონაცემების დამუშავების დროს.';
            } else {
                let {user, password} = req.body;
                // password = crypto.hash(password);
                pool = await db.connect();

                let rows = await db.execQuery(pool,
                    "select ID EntrantId " +
                    " from tEntrants " +
                    " where idNum = :user and [ExamPaperNum] =:password and [EntrantTypeID]=1", {user, password});

                if (rows.length === 1) {
                    EntrantId = +rows[0].EntrantId;
                    req.session.entrantId = +EntrantId;

                    // let stageData = await db.execQuery(pool,"")

                } else
                    err = 'მომხმარებელი ვერ მოიძებნა.';
            }
            if (!err) {
                res.json({EntrantId});
            } else
                res.json({err});

        } catch (err) {
            console.error(err);
            next(err);
        } finally {
            await db.close(pool);
        }

    },
    async getScriptPoionts(req, res, next) {
        let entrantId = -1;
        let err = "";


        if (!req.session.entrantId) {
            err = "სისტემური შეცდომაა(code: 21). დახურეთ ბრაუზერი და თავიდან სცადეთ.";
            res.json({err});
            return;
        }
        entrantId = req.session.entrantId;

        let ueedb_1_conn = req.app.get("ueedb_1_conn"),
            ueedb_2_conn = req.app.get("ueedb_2_conn");

        let ueedb_1, ueedb_2;
        try {
            ueedb_1 = new sqlEngine.ConnectionPool(ueedb_1_conn);
            ueedb_2 = new sqlEngine.ConnectionPool(ueedb_2_conn);
            await Promise.all([ueedb_1.connect(), ueedb_2.connect()]);
            let scriptPoints = await getScriptRawPoints(entrantId, ueedb_2);
            req.session.barcodes = scriptPoints.map(function (item) {
                return {subjectID: +item.SubjectID, barcodeID: +item.BarcodeID}
            });
            let scripts = [];
            let subject;

            let len = scriptPoints.length;
            for (let i = 0; i < len; i++) {

                let cacheName = 'ueeres-sp-' + entrantId.toString() + '-' + scriptPoints[i].SubjectID;
                let cachedData = await memcached.get(cacheName);
                if (!cachedData) {
                    subject = scriptPoints[i];
                    let [itemPoints, scriptTemplates] = await Promise.all(
                        [getItemPoints(subject.BarcodeID, subject.RawPointsMultiplier || 1, ueedb_1),
                            getScriptTemplates(subject.SubjectID, ueedb_2)]);

                    subject.ItemPoints = scriptTemplates.map(function (st) {
                        return Object.assign(st, itemPoints.find((sp) => {
                            return sp.PageNum === st.PageNum && st.TaskNum === sp.ItemNum
                        }));
                    });


                    await memcached.set(cacheName, subject, 60 * 24 * 10);
                } else
                    subject = cachedData;
                scripts.push(subject);
            }

            res.json({scripts})


        } catch
            (err) {
            console.log(err);
            next(err);
        } finally {
            if (ueedb_2)
                ueedb_2.close();
            if (ueedb_1)
                ueedb_1.close();
        }
    },
    async getScriptImage(req, res, next) {
        let barcodes;
        let ueedb_1, ueedb_2;

        if (req.session && req.session.barcodes)
            barcodes = req.session.barcodes;
        else {
            res.status(404).send("<strong>ნაშრომის დასკანირებული ფაილი არ მოიძებნა</strong>");
            return;
        }


        let subjectID = req.query.s;
        let page = req.query.p;
        let subjectBarcode = barcodes.find(function (item) {
            return item.subjectID === +subjectID
        });

        if (subjectBarcode) {
            let imageKey = "ueeres_image_" + subjectBarcode.barcodeID.toString() + "_" + page.toString();

            /*   let cachedData = await memcached.get(imageKey);
               if (cachedData && 0) {
                   res.set('Content-Type', 'image/tiff');
                   res.set('Content-Disposition', 'filename=script' + subjectID + '_' + (parseInt(page) + 1) + '.tiff');
                   res.send(cachedData);
               } else */
            {
                try {
                    let ueedb_1_conn = req.app.get("ueedb_1_conn");
                    ueedb_1 = new sqlEngine.ConnectionPool(ueedb_1_conn);
                    await ueedb_1.connect();
                    let scriptImage = await getImage(subjectBarcode.barcodeID, page, ueedb_1);
                    if (scriptImage.length > 0) {
                        // memcached.set(imageKey, scriptImage[0].Image, 3600);
                        res.set('Content-Type', 'image/tiff');
                        res.set('Content-Disposition', 'filename=script' + subjectID + '_' + (parseInt(page) + 1) + '.tiff');
                        res.send(scriptImage[0].Image);

                    } else {
                        res.status(404).send("<strong>ნაშრომის დასკანირებული ფაილი არ მოიძებნა</strong>");
                    }
                } catch (err) {
                    console.log(err)
                    next(err);
                } finally {
                    if (ueedb_1)
                        ueedb_1.close()
                }

            }
        } else
            res.status(404).send("<strong>ნაშრომის დასკანირებული ფაილი არ მოიძებნა</strong>");
    },

    getTestImage: function (req, res) {
        let subjectID = req.params.subjectID;
        let attName = 's' + subjectID.toString();

        attName = attName + '.pdf';

        res.attachment(attName);
        let fileName = path.join(__dirname, '../tests', 's' + subjectID.toString() + '.pdf');
        res.sendFile(fileName);
    },

    async getAdmission(req, res, next) {
        if (!req.session.entrantId) {
            let err = "სისტემური შეცდომაა(code: 21). დახურეთ ბრაუზერი და თავიდან სცადეთ.";
            res.json({err});
            return;
        }
        let entrantId = req.session.entrantId;
        let ueedb_2;
        let admission;

        try {
            let cacheName = 'ueeres-adm-' + entrantId.toString();
            let cachedData = await memcached.get(cacheName);
            if (!cachedData) {

                let ueedb_2_conn = req.app.get("ueedb_2_conn");
                ueedb_2 = new sqlEngine.ConnectionPool(ueedb_2_conn);
                await ueedb_2.connect();

                admission = await getAdmission(entrantId, ueedb_2);
                await memcached.set(cacheName, admission, 60 * 24 * 10);
            } else
                admission = cachedData;

            res.json({admission});
        } catch (err) {
            console.log(err);
            next(err);
        } finally {
            if (ueedb_2)
                ueedb_2.close();
        }
    },
    async getScores(req, res, next) {
        let pool;
        let Scores;
        try {
            if (!req.session.entrantId) {
                let err = "სისტემური შეცდომაა(code: 21). დახურეთ ბრაუზერი და თავიდან სცადეთ.";
                res.json({err});
                return;
            }

            let entrantId = req.session.entrantId;
            let cacheName = 'ueeres-sc-' + entrantId.toString();
            let cachedData = await memcached.get(cacheName);
            if (!cachedData) {
                let entrantId = req.session.entrantId;
                pool = await db.connect();

                Scores = await db.execQuery(pool,
                    "EXEC [dbo].[sp08_EntrantScores]  :entrantId", {entrantId});
                await memcached.set(cacheName, Scores, 60 * 24 * 10);
            } else
                Scores = cachedData;

            res.json({Scores})

        } catch (err) {
            console.error(err);
            next(err);
        } finally {
            await db.close(pool);
        }
    },
    async clearCache(req, res) {
        try {
            await memcached.flush();
            res.send("Cache cleared");
        } catch (e) {
            res.send(e);
        }

    }
};
