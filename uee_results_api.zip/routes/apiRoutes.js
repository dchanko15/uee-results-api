let express = require("express");
let apiScripts = require("../scriptpoints");

let router = express.Router();

router.post('/login', apiScripts.loginSchema, apiScripts.login);
router.get('/scripts', apiScripts.getScriptPoionts);
router.get('/scriptimage', apiScripts.getScriptImage);
router.get('/admission', apiScripts.getAdmission);
router.get('/scores', apiScripts.getScores);
router.get('/clearcache', apiScripts.clearCache);


module.exports = router;
